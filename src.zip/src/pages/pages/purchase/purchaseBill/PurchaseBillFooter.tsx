import React, { useImperativeHandle, forwardRef, useRef, useState, useEffect } from 'react';
import { EditIcon } from 'lucide-react';
import { COLORS } from '../../../../constants/colors';
import Attachment from '../../../../components/Attachment';
import Dropdown, { ColumnDef } from '../../../../components/Dropdown';
import ChartOfAccounts from '../../../../components/ChartOfAccount';
import { SalesAndPurchaseGL } from '../../../../components/addItemMaster/api/saleAndPurchaseGL';
import chartOfAccountService from '../../../../services/chartOfAccountService';

export interface PurchaseBillFooterRef {
  getFooterData: () => {
    remarks: string;
    receivedAmount: number;
    cashBankLedger: string;
    itemValue: number;
    discount1: number;
    discount2: number;
    taxable: number;
    taxAmount: number;
    transportVal: number;
    transportAmt: number;
    otherDiscVal: number;
    otherDiscAmt: number;
    adjustmentVal: number;
    adjustmentAmt: number;
    roundOff: number;
    docAmount: number;
    promoDiscount: number;
    payments: Array<{
      ledger: string;
      amount: number;
      remarks: string;
    }>;
  };
}

type InvoiceFooterProps = {
  amount?: number;
  cashCredit?: string;
  currentItems?: any[];
};

interface GlOption {
  _id: string;
  name: string;
  code: string;
  type?: string;
  underGroup: string;
  nature: string;
  label: string;
  value: string;
  underGroupCode?: string;
}

const glColumns: ColumnDef<any>[] = [
  { header: 'Code', key: 'code', width: 'w-1/5' },
  { header: 'Name', key: 'name', width: 'w-2/5' },
  { header: 'Group', key: 'underGroup', width: 'auto' },
];

const PurchaseBillFooter = forwardRef<PurchaseBillFooterRef, InvoiceFooterProps>(
  ({ cashCredit, currentItems }, ref) => {
    const remarksRef = useRef<HTMLTextAreaElement>(null);
    const receivedAmountRef = useRef<HTMLInputElement>(null);

    const itemValueRef = useRef<HTMLInputElement>(null);
    const discount1Ref = useRef<HTMLInputElement>(null);
    const discount2Ref = useRef<HTMLInputElement>(null);
    const taxableRef = useRef<HTMLInputElement>(null);
    const taxAmountRef = useRef<HTMLInputElement>(null);
    const roundOffRef = useRef<HTMLInputElement>(null);
    const docAmountRef = useRef<HTMLInputElement>(null);

    const transportAmtRef = useRef<HTMLInputElement>(null);
    const otherDiscAmtRef = useRef<HTMLInputElement>(null);
    const adjustmentAmtRef = useRef<HTMLInputElement>(null);
    const promoDiscountRef = useRef<HTMLInputElement>(null);

    const [glOptions, setGlOptions] = useState<GlOption[]>([]);

    // FIX: Independent state for each of the 3 ledger rows
    const [selectedLedgers, setSelectedLedgers] = useState<string[]>([
      'Cash In Hand',
      'Cash In Hand',
      'Cash In Hand',
    ]);

    const [showChartOfAccounts, setShowChartOfAccounts] = useState(false);
    const [coaFormData, setCoaFormData] = useState<SalesAndPurchaseGL | null>(null);
    const [activeLedgerIndex, setActiveLedgerIndex] = useState<number>(0);

    const updateLedgerAt = (index: number, value: string) => {
      const updated = [...selectedLedgers];
      updated[index] = value;
      setSelectedLedgers(updated);
    };

    const calculateFinalDocAmount = () => {
      const getVal = (r: React.RefObject<HTMLInputElement | null>) => Number(r.current?.value || 0);
      const finalTotal =
        getVal(taxableRef) +
        getVal(taxAmountRef) +
        getVal(transportAmtRef) +
        getVal(adjustmentAmtRef) +
        getVal(roundOffRef) -
        getVal(otherDiscAmtRef);
      if (docAmountRef.current) docAmountRef.current.value = finalTotal.toFixed(2);
    };

    useEffect(() => {
      if (!currentItems?.length) return;
      let totalItemValue = 0,
        totalTaxable = 0,
        totalTaxAmount = 0;
      currentItems.forEach((row: any) => {
        const item = row.data || row;
        const amount = Number(item.amount || Number(item.qty || 0) * Number(item.rate || 0));
        const gstRate = Number(item.gstRate || 0);
        const itemTaxable = amount / (1 + gstRate / 100);
        totalItemValue += amount;
        totalTaxable += itemTaxable;
        totalTaxAmount += amount - itemTaxable;
      });
      if (itemValueRef.current) itemValueRef.current.value = totalItemValue.toFixed(2);
      if (taxableRef.current) taxableRef.current.value = totalTaxable.toFixed(2);
      if (taxAmountRef.current) taxAmountRef.current.value = totalTaxAmount.toFixed(2);
      calculateFinalDocAmount();
    }, [currentItems]);

    useEffect(() => {
      const loadData = async () => {
        try {
          const res = await chartOfAccountService.getAllChartOfAccounts();
          if (Array.isArray(res.data)) {
            const mapped = res.data
              .map((item: any) => ({
                ...item,
                name: item.name || '',
                code: item.code || 'N/A',
                underGroup:
                  typeof item.underGroup === 'object'
                    ? item.underGroup?.name
                    : item.underGroup || '',
                label: item.name,
                value: item._id,
              }))
              .filter((item: any) => item.type === 'Bank' || item.type === 'Cash');
            setGlOptions(mapped);
          }
        } catch (e) {
          console.error(e);
        }
      };
      loadData();
    }, []);

    useImperativeHandle(ref, () => ({
      getFooterData: () => {
        const receivedAmt = parseFloat(receivedAmountRef.current?.value || '0');

        // Find the GL details for the currently active/first ledger selected
        const activeGl = glOptions.find((opt) => opt.name === selectedLedgers[0]);

        // Generate payments list from the selected ledgers
        // Here we assume the total received amount is distributed or just sent with the primary ledger
        const paymentsList = selectedLedgers
          .map((name) => glOptions.find((opt) => opt.name === name))
          .filter((gl) => gl !== undefined)
          .map((gl) => ({
            ledger: gl!.code,
            amount: receivedAmt, // You can adjust logic here if amounts are split
            remarks: remarksRef.current?.value || 'Payment against purchase bill',
          }))
          .slice(0, 1); // Taking the first one as per your snippet requirement

        return {
          remarks: remarksRef.current?.value || '',
          receivedAmount: receivedAmt,
          cashBankLedger: activeGl?.code || '',
          payments: paymentsList,
          itemValue: parseFloat(itemValueRef.current?.value || '0'),
          discount1: parseFloat(discount1Ref.current?.value || '0'),
          discount2: parseFloat(discount2Ref.current?.value || '0'),
          promoDiscount: parseFloat(promoDiscountRef.current?.value || '0'),
          taxable: parseFloat(taxableRef.current?.value || '0'),
          taxAmount: parseFloat(taxAmountRef.current?.value || '0'),
          transportVal: 0,
          transportAmt: parseFloat(transportAmtRef.current?.value || '0'),
          otherDiscVal: 0,
          otherDiscAmt: parseFloat(otherDiscAmtRef.current?.value || '0'),
          adjustmentVal: 0,
          adjustmentAmt: parseFloat(adjustmentAmtRef.current?.value || '0'),
          roundOff: parseFloat(roundOffRef.current?.value || '0'),
          docAmount: parseFloat(docAmountRef.current?.value || '0'),
        };
      },
    }));

    const handleOpenCOA = (index: number) => {
      setActiveLedgerIndex(index);
      const selectedItem = glOptions.find((item) => item.name === selectedLedgers[index]);
      setCoaFormData(
        (selectedItem as unknown as SalesAndPurchaseGL) ||
          ({ name: selectedLedgers[index] } as SalesAndPurchaseGL)
      );
      setShowChartOfAccounts(true);
    };

    const handleSaveCOA = (savedData: SalesAndPurchaseGL) => {
      if (savedData?.name) {
        updateLedgerAt(activeLedgerIndex, savedData.name);
        window.location.reload();
      }
      setShowChartOfAccounts(false);
    };

    const ActionBtn = ({ onClick, icon }: any) => (
      <button
        type="button"
        onClick={onClick}
        className="z-10 ml-[-1px] flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-sm text-white"
        style={{ backgroundColor: COLORS.primary }}>
        {icon}
      </button>
    );

    return (
      <div
        className="w-full border-t p-4 font-sans text-sm"
        style={{ backgroundColor: COLORS.white }}>
        <div className="flex flex-col gap-8 lg:flex-row">
          <div className="flex flex-1 flex-col gap-4">
            <div className="flex flex-col gap-4 sm:flex-row">
              <label className="mt-1 w-32 text-xs font-medium">Remarks</label>
              <textarea
                ref={remarksRef}
                className="custom-input h-20 w-full resize-none rounded-sm border p-2 text-xs outline-none"
                style={{ borderColor: COLORS.borderDark }}
              />
            </div>

            {cashCredit === 'Credit' && (
              <div className="flex flex-col items-center gap-4 sm:flex-row">
                <label className="w-32 text-xs font-medium">Paid Amount</label>
                <div className="relative w-40">
                  <span className="absolute left-2 top-1/2 -translate-y-1/2 text-xs">₹</span>
                  <input
                    ref={receivedAmountRef}
                    type="text"
                    defaultValue="0.00"
                    className="custom-input w-full rounded-sm border py-1 pl-6 pr-2 text-right text-xs outline-none"
                    style={{ borderColor: COLORS.borderDark }}
                  />
                </div>
              </div>
            )}

            {/* LEDGER ROW 1 */}
            <div className="flex flex-col items-center gap-4 sm:flex-row">
              <label className="w-32 text-xs font-medium">Cash/Bank Ledger</label>
              <div className="flex flex-1 items-center gap-0">
                <div className="flex-1">
                  <Dropdown
                    data={glOptions}
                    columns={glColumns}
                    value={selectedLedgers[0]}
                    valueKey="name"
                    onChange={(item) => updateLedgerAt(0, item?.name || '')}
                  />
                </div>
                <ActionBtn icon={<EditIcon size={14} />} onClick={() => handleOpenCOA(0)} />
              </div>
            </div>

            {/* LEDGER ROW 2 & 3 (Conditional) */}
            {cashCredit === 'Cash' && (
              <>
                <div className="flex flex-col items-center gap-4 sm:flex-row">
                  <label className="w-32 text-xs font-medium">Cash/Bank Ledger</label>
                  <div className="flex flex-1 items-center gap-0">
                    <div className="flex-1">
                      <Dropdown
                        data={glOptions}
                        columns={glColumns}
                        value={selectedLedgers[1]}
                        valueKey="name"
                        onChange={(item) => updateLedgerAt(1, item?.name || '')}
                      />
                    </div>
                    <ActionBtn icon={<EditIcon size={14} />} onClick={() => handleOpenCOA(1)} />
                  </div>
                </div>
                <div className="flex flex-col items-center gap-4 sm:flex-row">
                  <label className="w-32 text-xs font-medium">Cash/Bank Ledger</label>
                  <div className="flex flex-1 items-center gap-0">
                    <div className="flex-1">
                      <Dropdown
                        data={glOptions}
                        columns={glColumns}
                        value={selectedLedgers[2]}
                        valueKey="name"
                        onChange={(item) => updateLedgerAt(2, item?.name || '')}
                      />
                    </div>
                    <ActionBtn icon={<EditIcon size={14} />} onClick={() => handleOpenCOA(2)} />
                  </div>
                </div>
              </>
            )}

            <div className="mt-2 flex flex-col gap-4 sm:flex-row">
              <label className="w-32 pt-2 text-xs font-medium">Attachment</label>
              <div className="flex-1">
                <Attachment />
              </div>
            </div>
          </div>

          <div className="flex w-full flex-col gap-2 lg:w-[400px]">
            <TotalRow label="Item Value" inputRef={itemValueRef} />
            <TotalRow label="Discount" inputRef={discount1Ref} />
            <TotalRow label="Discount" inputRef={discount2Ref} />
            <TotalRow label="Taxable" inputRef={taxableRef} />
            <TotalRow label="Tax Amount" inputRef={taxAmountRef} />
            <SplitTotalRow
              label="Transport"
              amtRef={transportAmtRef}
              taxableRef={taxableRef}
              onUpdate={calculateFinalDocAmount}
            />
            <SplitTotalRow
              label="Other Discount"
              amtRef={otherDiscAmtRef}
              taxableRef={taxableRef}
              onUpdate={calculateFinalDocAmount}
            />
            <SplitTotalRow
              label="Adjustment"
              amtRef={adjustmentAmtRef}
              taxableRef={taxableRef}
              onUpdate={calculateFinalDocAmount}
            />
            <div className="grid grid-cols-[1fr_120px] items-center gap-2">
              <label className="text-xs">Round Off</label>
              <input
                ref={roundOffRef}
                type="text"
                defaultValue="0.00"
                onChange={calculateFinalDocAmount}
                className="w-full rounded-sm border py-1 pr-2 text-right text-xs outline-none"
                style={{ borderColor: COLORS.borderDark }}
              />
            </div>
            <div className="mt-1 grid grid-cols-[1fr_120px] items-center gap-2 font-bold">
              <label className="text-xs">Doc Amount</label>
              <input
                ref={docAmountRef}
                type="text"
                readOnly
                className="w-full rounded-sm border bg-gray-50 py-1 pr-2 text-right text-xs outline-none"
                style={{ borderColor: COLORS.borderDark }}
              />
            </div>
          </div>
        </div>

        {showChartOfAccounts && (
          <div
            className="fixed inset-0 flex items-center justify-center bg-black/50 p-4"
            style={{ zIndex: 1000 }}>
            <div className="max-h-[90vh] w-full max-w-4xl overflow-auto rounded bg-white shadow-lg">
              <ChartOfAccounts
                isOpen={showChartOfAccounts}
                onClose={() => setShowChartOfAccounts(false)}
                initialData={coaFormData}
                onSave={handleSaveCOA}
              />
            </div>
          </div>
        )}
      </div>
    );
  }
);

const TotalRow = ({ label, inputRef }: any) => (
  <div className="grid grid-cols-[1fr_120px] items-center gap-2">
    <label className="text-xs text-gray-500">{label}</label>
    <input
      ref={inputRef}
      type="text"
      readOnly
      className="w-full rounded-sm border bg-gray-50 py-1 pr-2 text-right text-xs outline-none"
      style={{ borderColor: COLORS.borderDark }}
    />
  </div>
);

const SplitTotalRow = ({ label, amtRef, onUpdate }: any) => (
  <div className="grid grid-cols-[1fr_120px] items-center gap-2">
    <label className="text-xs text-gray-500">{label}</label>
    <input
      ref={amtRef}
      type="text"
      defaultValue="0.00"
      onChange={onUpdate}
      className="w-full rounded-sm border py-1 pr-2 text-right text-xs outline-none"
      style={{ borderColor: COLORS.borderDark }}
    />
  </div>
);

export default PurchaseBillFooter;
