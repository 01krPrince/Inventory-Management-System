export const BASE_URL: string =
  import.meta.env.VITE_API_BASE_URL || "https://api.ims.infoera.in/api";
